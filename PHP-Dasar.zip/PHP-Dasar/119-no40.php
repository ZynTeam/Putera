<?php
$siswa = ["satu"=>"Andri","dua"=>"Joko","tiga"=>"Sukma","empat"=>"Rina"];

echo "<pre>"
print_r ($siswa);
echo "</pre>";