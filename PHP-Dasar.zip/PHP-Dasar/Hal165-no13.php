<?php
$hari = 4
;
switch ($hari) {
    case 1 :
        echo "hari Senin";
        break;
    case 2 :
        echo "hari Selasa";
        break;
    case 3 :
        echo "hari Rabu";
        break;
    case 4 :
        echo "hari Kamis";
        break;
    case 5 :
        echo "hari Jum'at";
        break;
    case 6 :
        echo "hari Sabtu";
        break;
    case 7 :
        echo "hari Minggu";
        break;
    default :
        echo "Nama hari cuma ada 7!";
        break;
}
?>