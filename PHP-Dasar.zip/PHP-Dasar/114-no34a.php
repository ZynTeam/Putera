<?php
    $macam2 = array(121,"Joko",44.99,"Belajar PHP");
    $macam2[10] = "Duniailkom";
    $macam2[100] = 212;
    $macam2[1000] = 3.14;

    echo"<pre>";
    var_dump($macam2);
    echo "</pre>";

?>