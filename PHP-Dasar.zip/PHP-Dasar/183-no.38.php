<?php
$nama = array("andri","joko","sukma","rina","sari");

for ($i = 0; $i < 5; $i++) {
    echo "nama[$i] <br>";
}
?>