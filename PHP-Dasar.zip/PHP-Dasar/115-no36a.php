<?php
    $macam2 = array(121,"Joko",44.99,"Belajar PHP");
    $macam2[1] = "Duniailkom";
    $macam2[2] = 212;

    echo"<pre>";
    var_dump($macam2);
    echo "</pre>";

?>      