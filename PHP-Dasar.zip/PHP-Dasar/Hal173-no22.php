<?php
for ($i = 1; $i < 100; $i++) {
    echo "Anak kucing ada $i<br>";
}
    ?>