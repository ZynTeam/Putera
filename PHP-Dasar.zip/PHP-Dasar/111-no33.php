<?php
  $siswa = array("Andri","Joko","Sukma","Rina","Sari");

  echo $siswa[2];
  echo "<br>";
  echo "Murid itu bernama $siswa[0]";

  ?>