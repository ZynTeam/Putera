<?php
    $siswa = array(
                    "satu"  => "Andri",
                    "dua"  => "Joko",
                    "tiga"  => "Sukma",
                    "empat"  => "Rina"
                    );

    echo $siswa["dua"];
    echo "<br>";

    ?>