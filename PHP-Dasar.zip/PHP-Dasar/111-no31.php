<?php
  $siswa0="Andri";
  $siswa1="Joko";
  $siswa2="Sukma";
  $siswa3="Rina";
  $siswa4="Sari";

  echo $siswa1; // Joko

  ?>