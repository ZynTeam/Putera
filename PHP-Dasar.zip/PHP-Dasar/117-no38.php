<?php
    $koordinat = [[8,2],[2,4],[1,7]];

    echo "<pre>";
    print_r($koordinat);
    echo "</pre>";